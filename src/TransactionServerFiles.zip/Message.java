
public class Message {

}
