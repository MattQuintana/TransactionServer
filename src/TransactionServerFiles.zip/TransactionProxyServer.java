// Who the client calls high level calls towards 
// The proxy will then do the low level network calls
// such as creating the sockets and sending the messages
public class TransactionProxyServer {

	// Take in the high level call
	
	// Connect to the transaction server
		// Package the high level call information into a message 
		// Connect to the transaction server
			// Create a socket with the port and IP of the TransactionServer
			// Maybe the Proxy should have an idea about the actual server
		// Pass the message to it 
}
